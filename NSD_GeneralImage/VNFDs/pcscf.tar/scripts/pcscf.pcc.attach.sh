#!/bin/bash

screen -wipe
screen -r pcscf.pcc
