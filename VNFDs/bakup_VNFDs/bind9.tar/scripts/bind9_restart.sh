#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr
#        : Sakib37

# bind9 restart script.

service bind9 restart
