#!/bin/bash

screen -wipe
screen -r scscf
