#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# bind9 restart script.

service bind9 restart
