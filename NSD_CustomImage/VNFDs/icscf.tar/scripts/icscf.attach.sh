#!/bin/bash

screen -wipe
screen -r icscf
